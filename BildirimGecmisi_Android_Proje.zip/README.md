# Bildirim Geçmişi (Android)

Bu, Android Studio'da açılabilen başlangıç projesidir. WhatsApp, Instagram ve diğer uygulamalardan Android'in bildirim paneline düşen, okunabilir metin içeren bildirimleri cihazdaki SQLite veritabanına kaydeder.

## Çalıştırma
1. Android Studio'da bu klasörü aç.
2. Gradle senkronizasyonunun tamamlanmasını bekle.
3. Uygulamayı Android telefonuna yükle.
4. Uygulamada **Bildirim erişimini etkinleştir** düğmesine bas.
5. Android ayarlarında **Bildirim Geçmişi** erişimini etkinleştir.
6. Yeni bildirimler geldikçe ana ekranda görünür. Yenile düğmesi listeyi tekrar okur.

## Kayıt bilgileri
- Uygulama paket adı
- Bildirim başlığı / görünen metin
- Uygulamanın bildirim zamanı ve cihazın yakaladığı zaman
- Yakalama zamanı milisaniye hassasiyetinde saklanır; arayüzde saniye olarak gösterilir.

## Önemli sınırlar
- Uygulama geçmişteki bildirimleri geriye dönük alamaz; erişim açıldıktan sonra gelen bildirimleri kaydeder.
- Bir uygulama bildirimde mesaj metnini gizlerse, Android'e yalnızca o metin ulaşırsa kaydedilebilir. Görsel, ses, tam sohbet geçmişi veya uygulama içindeki mesajlar otomatik olarak alınmaz.
- Android'in bildirim erişimi izni gerekir. Bazı cihazlar pil optimizasyonu nedeniyle servisi durdurabilir.
- Kayıtlar bu prototipte cihazda yerel tutulur; uygulama verileri silinirse kayıtlar da silinir.
- Bildirimlerde özel/kişisel bilgiler bulunabilir. Telefonunu koru; başkalarının cihazlarında izinsiz kullanma.
