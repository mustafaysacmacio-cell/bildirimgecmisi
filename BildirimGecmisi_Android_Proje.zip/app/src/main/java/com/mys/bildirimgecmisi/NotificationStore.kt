package com.mys.bildirimgecmisi

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class SavedNotification(
    val id: Long,
    val app: String,
    val title: String,
    val body: String,
    val receivedAt: Long
)

class NotificationStore(context: Context) :
    SQLiteOpenHelper(context, "notification_history.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                app TEXT NOT NULL,
                title TEXT NOT NULL,
                body TEXT NOT NULL,
                posted_at INTEGER NOT NULL,
                received_at INTEGER NOT NULL
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX idx_received_at ON notifications(received_at DESC)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) { }

    fun insert(packageName: String, title: String, body: String, postedAt: Long, receivedAt: Long) {
        val values = ContentValues().apply {
            put("app", packageName)
            put("title", title)
            put("body", body)
            put("posted_at", postedAt)
            put("received_at", receivedAt)
        }
        writableDatabase.insert("notifications", null, values)
    }

    fun all(search: String = ""): List<SavedNotification> {
        val result = mutableListOf<SavedNotification>()
        val db = readableDatabase
        val cursor = if (search.isBlank()) {
            db.rawQuery("SELECT id,app,title,body,received_at FROM notifications ORDER BY received_at DESC", null)
        } else {
            val like = "%$search%"
            db.rawQuery(
                "SELECT id,app,title,body,received_at FROM notifications WHERE app LIKE ? OR title LIKE ? OR body LIKE ? ORDER BY received_at DESC",
                arrayOf(like, like, like)
            )
        }
        cursor.use {
            while (it.moveToNext()) {
                result += SavedNotification(
                    id = it.getLong(0),
                    app = it.getString(1),
                    title = it.getString(2),
                    body = it.getString(3),
                    receivedAt = it.getLong(4)
                )
            }
        }
        return result
    }

    fun deleteAll() {
        writableDatabase.delete("notifications", null, null)
    }
}
