package com.mys.bildirimgecmisi

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NotificationHistoryScreen() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationHistoryScreen() {
    val context = LocalContext.current
    val store = remember { NotificationStore(context) }
    var search by remember { mutableStateOf("") }
    var refresh by remember { mutableIntStateOf(0) }
    val entries = remember(search, refresh) { store.all(search) }
    val listenerEnabled = remember(refresh) {
        val enabled = Settings.Secure.getString(
            context.contentResolver, "enabled_notification_listeners"
        ).orEmpty()
        enabled.contains(context.packageName)
    }
    val formatter = remember { SimpleDateFormat("dd.MM.yyyy HH:mm:ss", Locale("tr", "TR")) }

    MaterialTheme {
        Scaffold(topBar = { TopAppBar(title = { Text("Bildirim Geçmişi") }) }) { padding ->
            Column(Modifier.padding(padding).padding(16.dp).fillMaxSize()) {
                Text(
                    "Bildirimler cihazında yerel olarak saklanır.",
                    style = MaterialTheme.typography.bodyMedium
                )
                Spacer(Modifier.height(10.dp))
                Button(
                    onClick = { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(if (listenerEnabled) "Bildirim erişimi ayarları" else "Bildirim erişimini etkinleştir")
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = search,
                    onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Uygulama, kişi veya mesaj ara") },
                    singleLine = true
                )
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("${entries.size} kayıt", style = MaterialTheme.typography.labelLarge)
                    TextButton(onClick = { refresh++ }) { Text("Yenile") }
                }
                if (entries.isEmpty()) {
                    Text("Henüz kayıt yok. Bildirim erişimini açıp yeni bir bildirim bekle.", modifier = Modifier.padding(top = 12.dp))
                } else {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(entries, key = { it.id }) { item ->
                            ElevatedCard(Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(12.dp)) {
                                    Text(item.title.ifBlank { item.app }, style = MaterialTheme.typography.titleMedium)
                                    if (item.body.isNotBlank()) {
                                        Spacer(Modifier.height(4.dp))
                                        Text(item.body, style = MaterialTheme.typography.bodyMedium)
                                    }
                                    Spacer(Modifier.height(6.dp))
                                    Text(item.app, style = MaterialTheme.typography.labelSmall)
                                    Text(
                                        formatter.format(Date(item.receivedAt)),
                                        style = MaterialTheme.typography.labelMedium
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
