package com.mys.bildirimgecmisi

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotificationCaptureService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        // Only capture notifications that actually expose readable text.
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?.takeIf { it.isNotBlank() }
            ?: extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()

        if (title.isBlank() && text.isBlank()) return
        // Avoid recording this app's own notifications.
        if (sbn.packageName == packageName) return

        val receivedAt = System.currentTimeMillis()
        NotificationStore(this).insert(
            packageName = sbn.packageName,
            title = title,
            body = text,
            postedAt = sbn.postTime,
            receivedAt = receivedAt
        )
    }
}
